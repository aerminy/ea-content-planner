import WeeklyContentPlanner from './components/WeeklyContentPlanner';

function App() {
  return <WeeklyContentPlanner />;
}

export default App;